# 350-project
Project for EECE 350 made by Tia Al Hajj, Talah Bou Hadir, Houssein Rachini, Bechara Rizk
Open the VM software, and copy paste the codes.
Split the screen by two in order to view both peers and run the codes on the terminal


For Phase 2 --> a folder of netem commands is present , in that folder you copy and paste into the terminal to simulate an unreliable network
Run the codes in the terminal, and a reliable transfer of the messages is taking place


For Phase 3 --> download the corresponding codes to send files. The gui displays a button of "Send file", type in the chat text box
and click the button to send the file.


You need modules magic(pip install python-magic) and libmagic(brew install libmagic)


The GUI needs tkinter to run --> (sudo apt-get install python3-tk)
The GUI is a default setting within all the codes, so it will run simultaneously.
